Copy patch to program folder and apply it.
Reg with any e-mail and key. (if needed)